using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player2Lives : MonoBehaviour
{
    Animator anim;
    // Start is called before the first frame update
    void Start()
    {
        anim = gameObject.GetComponent<Animator>();
    }

    // Update is called once per frame
    void Update()
    {
        if (PlayerSpawn.player2Lives == 3)
        {
            anim.Play("Blue3Lives");
        }
        if (PlayerSpawn.player2Lives == 2)
        {
            anim.Play("Blue2Lives");
        }
        if (PlayerSpawn.player2Lives == 1)
        {
            anim.Play("Blue1Live");
        }
        if (PlayerSpawn.player2Lives == 0)
        {
            anim.Play("BlueNoLives");
        }
    }
}
