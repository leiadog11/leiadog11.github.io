using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnManager : MonoBehaviour
{
    public GameObject HorizPlatform;
    public GameObject VertPlatform;
    public GameObject Spinner;
    public GameObject Turret;
    public Transform Spawner;
    public static string Object = " ";
    public static string Location = " ";
    public int randomizer;


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        SpinSpawn();
        TurretSpawn();
        HorizontalPlatform();
        VerticalPlatform();
    }


    //Spawning Methods
    public void SpinSpawn()
    {
        if (Object == "Spinner" && (Location == "Right")) //Spinner Right Choice
        {
            Debug.Log("Spinner Spawned");
            GameObject spin;
            spin = Instantiate(Spinner);
            randomizer = Random.Range(1, 6);

            if (randomizer == 1)
            {
                spin.transform.position = new Vector3(30f, 17.3f, 67f);
            }
            else if (randomizer == 2)
            {
                spin.transform.position = new Vector3(30f, 7.5f, 67f);
            }
            else if (randomizer == 3)
            {
                spin.transform.position = new Vector3(22f, 11.2f, 67f);
            }
            else if (randomizer == 4)
            {
                spin.transform.position = new Vector3(26.8f, 14.4f, 67f);
            }
            else if (randomizer == 5)
            {
                spin.transform.position = new Vector3(18.5f, 12.5f, 67f);
            }
            Object = " ";
            Location = " ";
        }//Spinner Right Choice

        if (Object == "Spinner" && (Location == "Up")) //Spinner Up Choice
        {
            Debug.Log("Spinner Spawned");
            GameObject spin;
            spin = Instantiate(Spinner);
            randomizer = Random.Range(1, 3);

            if (randomizer == 1)
            {
                spin.transform.position = new Vector3(14.6f, 19f, 67f);
            }
            else if (randomizer == 2)
            {
                spin.transform.position = new Vector3(14.6f, 14.4f, 67f);
            }
            Object = " ";
            Location = " ";
        }//Spinner Up Choice

        if (Object == "Spinner" && (Location == "Down")) //Spinner Down Choice
        {
            Debug.Log("Spinner Spawned");
            GameObject spin;
            spin = Instantiate(Spinner);
            randomizer = Random.Range(1, 3);

            if (randomizer == 1)
            {
                spin.transform.position = new Vector3(14.6f, 5.6f, 67f);
            }
            else if (randomizer == 2)
            {
                spin.transform.position = new Vector3(14.6f, 10f, 67f);
            }
            Object = " ";
            Location = " ";
        }//Spinner Down Choice

        if (Object == "Spinner" && (Location == "Left")) //Spinner Left Choice
        {
            Debug.Log("Spinner Spawned");
            GameObject spin;
            spin = Instantiate(Spinner);
            randomizer = Random.Range(1, 6);

            if (randomizer == 1)
            {
                spin.transform.position = new Vector3(9.9f, 12.6f, 67f);
            }
            else if (randomizer == 2)
            {
                spin.transform.position = new Vector3(0.08f, 17.6f, 67f);
            }
            else if (randomizer == 3)
            {
                spin.transform.position = new Vector3(0.08f, 6.5f, 67f);
            }
            else if (randomizer == 4)
            {
                spin.transform.position = new Vector3(3f, 11.6f, 67f);
            }
            else if (randomizer == 5)
            {
                spin.transform.position = new Vector3(0.5f, 9.11f, 67f);
            }
            Object = " ";
            Location = " ";
        }//Spinner Left Choice
    }
    public void TurretSpawn()
    {
        if (Object == "Turret" && (Location == "Right")) //Turret Right Choice
        {
            Debug.Log("Turret Spawned");
            GameObject turret;
            turret = Instantiate(Turret);
            randomizer = Random.Range(1, 4);

            if (randomizer == 1)
            {
                turret.transform.position = new Vector3(30.37f, 14f, 67f);
                turret.transform.Rotate(0f, 0f, 270.0f, Space.Self);
            }
            else if (randomizer == 2)
            {
                turret.transform.position = new Vector3(30.28f, 5.3f, 67f);
                turret.transform.Rotate(0f, 0f, 270.0f, Space.Self);
            }
            else if (randomizer == 3)
            {
                turret.transform.position = new Vector3(23.6f, 9.8f, 67f);
            }
            Object = " ";
            Location = " ";
        } //Turret Right Choice

        if (Object == "Turret" && (Location == "Up")) //Turret Up Choice
        {
            Debug.Log("Turret Spawned");
            GameObject turret;
            turret = Instantiate(Turret);
            randomizer = Random.Range(1, 4);

            if (randomizer == 1)
            {
                turret.transform.position = new Vector3(1.5f, 18.4f, 67f);
            }
            else if (randomizer == 2)
            {
                turret.transform.position = new Vector3(14.7f, 18.4f, 67f);
            }
            else if (randomizer == 3)
            {
                turret.transform.position = new Vector3(27.3f, 18.4f, 67f);
            }
            Object = " ";
            Location = " ";
            Object = " ";
            Location = " ";
        } //Turret Up Choice

        if (Object == "Turret" && (Location == "Down")) //Turret Down Choice
        {
            Debug.Log("Turret Spawned");
            GameObject turret;
            turret = Instantiate(Turret);
            randomizer = Random.Range(1, 4);

            if (randomizer == 1)
            {
                turret.transform.position = new Vector3(27.3f, 6.52f, 67f);
                turret.transform.Rotate(0f, 0.0f, 180.0f, Space.Self);
            }
            else if (randomizer == 2)
            {
                turret.transform.position = new Vector3(15.2f, 6.59f, 67f);
                turret.transform.Rotate(0f, 0f, 180.0f, Space.Self);
            }
            else if (randomizer == 3)
            {
                turret.transform.position = new Vector3(2.75f, 1.4f, 67f);
                turret.transform.Rotate(0f, 0f, 180.0f, Space.Self);
            }
            Object = " ";
            Location = " ";
            Object = " ";
            Location = " ";
        } //Turret Down Choice

        if (Object == "Turret" && (Location == "Left")) //Turret Left Choice
        {
            Debug.Log("Turret Spawned");
            GameObject turret;
            turret = Instantiate(Turret);
            randomizer = Random.Range(1, 4);

            if (randomizer == 1)
            {
                turret.transform.position = new Vector3(-1.36f, 14f, 67f);
                turret.transform.Rotate(0f, 0f, 90.0f, Space.Self);
            }
            else if (randomizer == 2)
            {
                turret.transform.position = new Vector3(-1.32f, 5.3f, 67f);
                turret.transform.Rotate(0f, 0f, 90.0f, Space.Self);
            }
            else if (randomizer == 3)
            {
                turret.transform.position = new Vector3(3.8f, 9.8f, 67f);
            }
            Object = " ";
            Location = " ";
            Object = " ";
            Location = " ";
        } //Turret Left Choice
    }
    public void HorizontalPlatform()
    {
        if (Object == "HorizPlatform" && (Location == "Right")) //Horizontal Right Choice
        {
            GameObject plat;
            plat = Instantiate(HorizPlatform);
            Debug.Log("Right Horizontal Platform Spawned");
            randomizer = Random.Range(1, 11);

            if (randomizer == 1)
            {
                plat.transform.position = new Vector3(31.3f, 9.7f, 67f);
            }
            else if (randomizer == 2)
            {
                plat.transform.position = new Vector3(28f, 6.8f, 67f);
            }
            else if (randomizer == 3)
            {
                plat.transform.position = new Vector3(24f, 8.8f, 67f);
            }
            else if (randomizer == 4)
            {
                plat.transform.position = new Vector3(19f, 12f, 67f);
            }
            else if (randomizer == 5)
            {
                plat.transform.position = new Vector3(19f, 8.3f, 67f);
            }
            else if (randomizer == 6)
            {
                plat.transform.position = new Vector3(24.5f, 16.4f, 67f);
            }
            else if (randomizer == 7)
            {
                plat.transform.position = new Vector3(31.4f, 18.4f, 67f);
            }
            else if (randomizer == 8)
            {
                plat.transform.position = new Vector3(17f, 11f, 67f);
            }
            else if (randomizer == 9)
            {
                plat.transform.position = new Vector3(24f, 8f, 67f);
            }
            else if (randomizer == 10)
            {
                plat.transform.position = new Vector3(21f, 15.2f, 67f);
            }
            Object = " ";
            Location = " ";
        } //Horizontal Right Choice

        if (Object == "HorizPlatform" && (Location == "Up")) //Horizontal Up Choice
        {
            Debug.Log("Up Horizontal Platform Spawned");
            GameObject plat;
            plat = Instantiate(HorizPlatform);
            randomizer = Random.Range(1, 5);

            if (randomizer == 1)
            {
                plat.transform.position = new Vector3(14.8f, 18.4f, 67f);
            }
            else if (randomizer == 2)
            {
                plat.transform.position = new Vector3(6.4f, 18.4f, 67f);
            }
            else if (randomizer == 3)
            {
                plat.transform.position = new Vector3(-0.3f, 18.4f, 67f);
            }
            else if (randomizer == 4)
            {
                plat.transform.position = new Vector3(24.7f, 18.4f, 67f);
            }
            Object = " ";
            Location = " ";
        } //Horizontal Up Choice

        if (Object == "HorizPlatform" && (Location == "Down")) //Horizontal Down Choice
        {
            Debug.Log("Down Horizontal Platform Spawned");
            GameObject plat;
            plat = Instantiate(HorizPlatform);
            randomizer = Random.Range(1, 7);

            if (randomizer == 1)
            {
                plat.transform.position = new Vector3(24.6f, 5.4f, 67f);
            }
            else if (randomizer == 2)
            {
                plat.transform.position = new Vector3(17.9f, 5.4f, 67f);
            }
            else if (randomizer == 3)
            {
                plat.transform.position = new Vector3(15.2f, 7.6f, 67f);
            }
            else if (randomizer == 4)
            {
                plat.transform.position = new Vector3(8.5f, 5.8f, 67f);
            }
            else if (randomizer == 5)
            {
                plat.transform.position = new Vector3(0.77f, 4.1f, 67f);
            }
            else if (randomizer == 6)
            {
                plat.transform.position = new Vector3(30f, 4.1f, 67f);
            }
            Object = " ";
            Location = " ";
        }//Horizontal Down Choice

        if (Object == "HorizPlatform" && (Location == "Left")) //Horizontal Left Choice
        {
            Debug.Log("Left Horizontal Platform Spawned");
            GameObject plat;
            plat = Instantiate(HorizPlatform);
            randomizer = Random.Range(1, 13);

            if(randomizer == 1)
            {
                plat.transform.position = new Vector3(0.55f, 7.4f, 67f);
            }
            else if (randomizer == 2)
            {
                plat.transform.position = new Vector3(6f, 9.5f, 67f);
            }
            else if (randomizer == 3)
            {
                plat.transform.position = new Vector3(-2.7f, 11.6f, 67f);
            }
            else if (randomizer == 4)
            {
                plat.transform.position = new Vector3(11f, 11.5f, 67f);
            }
            else if (randomizer == 5)
            {
                plat.transform.position = new Vector3(12f, 9.13f, 67f);
            }
            else if (randomizer == 6)
            {
                plat.transform.position = new Vector3(4.5f, 14f, 67f);
            }
            else if (randomizer == 7)
            {
                plat.transform.position = new Vector3(0.77f, 16f, 67f);
            }
            else if (randomizer == 8)
            {
                plat.transform.position = new Vector3(0.77f, 13f, 67f);
            }
            else if (randomizer == 9)
            {
                plat.transform.position = new Vector3(5f, 9.7f, 67f);
            }
            else if (randomizer == 10)
            {
                plat.transform.position = new Vector3(14.3f, 11f, 67f);
            }
            else if (randomizer == 11)
            {
                plat.transform.position = new Vector3(9.7f, 13.6f, 67f);
            }
            else if (randomizer == 12)
            {
                plat.transform.position = new Vector3(6.5f, 8f, 67f);
            }
            Object = " ";
            Location = " ";

        } //Horizontal Left Choice
    }
    public void VerticalPlatform()
    {
        if (Object == "VertPlatform" && (Location == "Right")) //Vertical Right Choice
        {
            GameObject plat;
            plat = Instantiate(VertPlatform);
            Debug.Log("Right Vertical Platform Spawned");
            randomizer = Random.Range(1, 8);
            if (randomizer == 1)
            {
                plat.transform.position = new Vector3(30f, 5.3f, 67f);
            }
            else if (randomizer == 2)
            {
                plat.transform.position = new Vector3(30f, 11.4f, 67f);
            }
            else if (randomizer == 3)
            {
                plat.transform.position = new Vector3(30f, 18.4f, 67f);
            }
            else if (randomizer == 4)
            {
                plat.transform.position = new Vector3(21.4f, 18.4f, 67f);
            }
            else if (randomizer == 5)
            {
                plat.transform.position = new Vector3(21.4f, 11.6f, 67f);
            }
            else if (randomizer == 6)
            {
                plat.transform.position = new Vector3(21.4f, 5.3f, 67f);
            }
            else if (randomizer == 7)
            {
                plat.transform.position = new Vector3(25.8f, 12.5f, 67f);
            }
            Object = " ";
            Location = " ";
        } //Vertical Right Choice

        if (Object == "VertPlatform" && (Location == "Up")) //Vertical Up Choice
        {
            GameObject plat;
            plat = Instantiate(VertPlatform);
            Debug.Log("Up Vertical Platform Spawned");
            randomizer = Random.Range(1, 4);
            if (randomizer == 1)
            {
                plat.transform.position = new Vector3(9.1f, 19.2f, 67f);
            }
            else if (randomizer == 2)
            {
                plat.transform.position = new Vector3(14f, 15f, 67f);
            }
            else if (randomizer == 3)
            {
                plat.transform.position = new Vector3(18.7f, 19f, 67f);
            }
            Object = " ";
            Location = " ";
        } //Vertical Up Choice

        if (Object == "VertPlatform" && (Location == "Down")) //Vertical Down Choice
        {
            GameObject plat;
            plat = Instantiate(VertPlatform);
            Debug.Log("Down Vertical Platform Spawned");
            randomizer = Random.Range(1, 4);
            if (randomizer == 1)
            {
                plat.transform.position = new Vector3(11.2f, 5.6f, 67f);
            }
            else if (randomizer == 2)
            {
                plat.transform.position = new Vector3(15.5f, 9.4f, 67f);
            }
            else if (randomizer == 3)
            {
                plat.transform.position = new Vector3(20.4f, 5.8f, 67f);
            }
            Object = " ";
            Location = " ";
        } //Vertical Down Choice

        if (Object == "VertPlatform" && (Location == "Left")) //Vertical Left Choice
        {
            GameObject plat;
            plat = Instantiate(VertPlatform);
            Debug.Log("Left Vertical Platform Spawned");
            randomizer = Random.Range(1, 7);
            if (randomizer == 1)
            {
                plat.transform.position = new Vector3(10f, 8.2f, 67f);
            }
            else if (randomizer == 2)
            {
                plat.transform.position = new Vector3(10f, 15.4f, 67f);
            }
            else if (randomizer == 3)
            {
                plat.transform.position = new Vector3(-1.8f, 15.4f, 67f);
            }
            else if (randomizer == 4)
            {
                plat.transform.position = new Vector3(-1.9f, 6.3f, 67f);
            }
            else if (randomizer == 5)
            {
                plat.transform.position = new Vector3(3.4f, 13.5f, 67f);
            }
            else if (randomizer == 6)
            {
                plat.transform.position = new Vector3(3.4f, 5.3f, 67f);
            }
            Object = " ";
            Location = " ";
        } //Vertical Left Choice
    }

    //Location Setting Methods
    public void SetUp()
    {
        Location = "Up";
        Debug.Log("Up Set");
    }
    public void SetDown()
    {
        Location = "Down";
        Debug.Log("Down Set");
    }
    public void SetLeft()
    {
        Location = "Left";
        Debug.Log("Left Set");
    }
    public void SetRight()
    {
        Location = "Right";
        Debug.Log("Right Set");
    }

    //Object Setting Methods
    public void SetSpinner()
    {
        Object = "Spinner";
        Debug.Log("Spinner Set");
    }
    public void SetTurret()
    {
        Object = "Turret";
        Debug.Log("Turret Set");
    }
    public void SetHorizontalPlatform()
    {
        Object = "HorizPlatform";
        Debug.Log("Horizontal Platform Set");
    }
    public void SetVerticalPlatform()
    {
        Object = "VertPlatform";
        Debug.Log("Vertical Platform Set");
    }



}
