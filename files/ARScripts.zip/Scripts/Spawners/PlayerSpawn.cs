using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerSpawn : MonoBehaviour
{
    GameObject[] platforms;
    public GameObject Player;
    GameObject currentPlatform;
    public static int playerIndex;
    public static bool player1 = true;
    public static int player1Lives = 3;
    public static int player2Lives = 3;
    // Start is called before the first frame update
    void Start()
    {
        platforms = GameObject.FindGameObjectsWithTag("Platform");
        playerIndex = Random.Range(0, platforms.Length);
        GameObject player;
        player = Instantiate(Player);
        currentPlatform = platforms[playerIndex];
        player.transform.position = new Vector3(currentPlatform.transform.position.x, currentPlatform.transform.position.y + 0.5f, 67f);
        Debug.Log(player1);
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
