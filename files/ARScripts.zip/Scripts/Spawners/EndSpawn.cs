using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EndSpawn : MonoBehaviour
{
    GameObject[] platforms;
    public GameObject End;
    GameObject currentPlatform;
    public int endIndex;
    // Start is called before the first frame update
    void Start()
    {
        StartCoroutine(WaitForSpawn());
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private IEnumerator WaitForSpawn()
    {
        yield return new WaitForSeconds(0.2f);
        SpawnCoin();
    }
    void SpawnCoin()
    {
        platforms = GameObject.FindGameObjectsWithTag("Platform");
        endIndex = Random.Range(0, platforms.Length);
        GameObject end;
        end = Instantiate(End);
        currentPlatform = platforms[endIndex];
        if (endIndex == PlayerSpawn.playerIndex)
        {
            SpawnCoin();
        }
        else
        {
            end.transform.position = new Vector3(currentPlatform.transform.position.x, currentPlatform.transform.position.y + 0.5f, 67f);
        }
    }
}
