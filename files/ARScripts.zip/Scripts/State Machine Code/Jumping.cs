using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Jumping : BaseState
{
    private Movement _sm;
    private float _horizontalInput;
    private float jumpForce = 1f;
    private Vector2 speed = new Vector2(10, 10);
    private Vector2 movement = new Vector2(1, 1);

    public Jumping(Movement stateMachine) : base("Jumping", stateMachine)
    {
        _sm = (Movement)stateMachine;
    }

    public override void Enter()
    {
        base.Enter();
        _horizontalInput = 0f;
    }

    public override void UpdateLogic()
    {
        base.UpdateLogic();
        _horizontalInput = Input.GetAxis("Horizontal");
        if (Mathf.Abs(_horizontalInput) < Mathf.Epsilon) //transitions to idle state
        {
            stateMachine.ChangeState(_sm.idleState);
        }
        if (Mathf.Abs(_horizontalInput) > Mathf.Epsilon) //transitions to moving state
        {
            stateMachine.ChangeState(_sm.movingState);
        }
    }
    public override void UpdatePhysics() //changes y position (makes object jump)
    {
        JumpsCounter.jumpCounter -= 1; //decreasing jump counter
        base.UpdatePhysics();
        Vector2 vel = _sm.rigidbody.velocity;
        vel.y = jumpForce * _sm.speed;
        _sm.rigidbody.velocity = vel;
    }
}
