using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class JumpsCounter : MonoBehaviour
{
    public static int jumpCounter = 3;
    Animator anim;

    void Start()
    {
        anim = gameObject.GetComponent<Animator>();
    }

    void Update()
    {
        //entire if statement is for jump counter animation
        if(jumpCounter == 3)
        {
            anim.Play("3Jumps");
        }
        if(jumpCounter == 2)
        {
            anim.Play("2Jumps");
        }
        if(jumpCounter == 1)
        {
            anim.Play("1Jump");
        }
        if(jumpCounter == 0)
        {
            anim.Play("NoJumps");
        }
    }
    
}
