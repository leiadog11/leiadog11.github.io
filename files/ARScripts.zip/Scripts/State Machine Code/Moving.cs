using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Moving : BaseState
{
    private float _horizontalInput;
    private Movement _sm;

    public Moving(Movement stateMachine) : base("Moving", stateMachine)
    {
        _sm = (Movement)stateMachine;
    }

    public override void Enter()
    {
        base.Enter();
        _horizontalInput = 0f;
    }

    public override void UpdateLogic()
    {
        base.UpdateLogic();
        _horizontalInput = Input.GetAxis("Horizontal");
        if(Mathf.Abs(_horizontalInput) < Mathf.Epsilon) //transistions to idle state
        {
            stateMachine.ChangeState(_sm.idleState);
        }
        if(Input.GetButtonDown("Jump")) //transitions to jump state
        {
            if (JumpsCounter.jumpCounter >= 1) //checks for jump counter
            {
                stateMachine.ChangeState(_sm.jumpingState);
            }
        }
    }
    public override void UpdatePhysics() //Actual movement inputs (makes character move right and left)
    {
        base.UpdatePhysics();
        Vector2 vel = _sm.rigidbody.velocity;
        vel.x = _horizontalInput * _sm.speed;
        _sm.rigidbody.velocity = vel;
    }
    
}
