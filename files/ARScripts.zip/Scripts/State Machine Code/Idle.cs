using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Idle : BaseState
{
    private float _horizontalInput;
    private Movement _sm;
 

    public Idle(Movement stateMachine) : base("Idle", stateMachine)
    {
        _sm = (Movement)stateMachine;
    }

    public override void Enter()
    {
        base.Enter();
        _horizontalInput = 0f;
    }

    public override void UpdateLogic()
    {
        base.UpdateLogic();
        _horizontalInput = Input.GetAxis("Horizontal");
        if(Mathf.Abs(_horizontalInput) > Mathf.Epsilon) //transitions to moving state
        {
            stateMachine.ChangeState(_sm.movingState);
        }
        if (Input.GetButtonDown("Jump")) //transitions to jump state
        {
            if (JumpsCounter.jumpCounter >= 1) //checks for jump counter
            {
                stateMachine.ChangeState(_sm.jumpingState);
            }
        }
    }
}
