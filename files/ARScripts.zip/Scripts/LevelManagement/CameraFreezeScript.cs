using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFreezeScript : MonoBehaviour
{
    public GameObject Camera;
    public Transform CameraPos;
    public bool Spawn;


    void Start()
    {
        Spawn = true;
    }

    void Update()
    {
        if (Input.GetButtonDown("Submit") && (Spawn == true))
        {
            CameraSpawn();
            Spawn = false;
        }
    }

    void CameraSpawn()
    {
        GameObject Cam = Instantiate(Camera);
        Cam.transform.position = CameraPos.position;
        this.gameObject.SetActive(false);
    }
}
