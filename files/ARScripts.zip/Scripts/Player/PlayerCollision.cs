using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerCollision : MonoBehaviour
{
    CameraFreezeScript camera;
    public bool canHit;
    // Start is called before the first frame update
    void Start()
    {
        canHit = true;
        camera = FindObjectOfType<CameraFreezeScript>();
        Player1Text.player1Message = " ";
        Player2Text.player2Message = " ";
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnCollisionExit2D(Collision2D coll)
    {
        string tagName = coll.collider.gameObject.tag;

        if (tagName == "avoid_me" && (canHit == true))
        {
            canHit = false;
            this.gameObject.transform.position = new Vector3(-100f, -100f, -100f);
            if (PlayerSpawn.player1 == true)
            {
                PlayerSpawn.player1Lives -= 1;
                if(PlayerSpawn.player1Lives == 0)
                {
                    Player1Text.player1Message = " ";
                    Player2Text.player2Message = "Player 2 Wins!";
                }
                else
                {
                    Player1Text.player1Message = "Player 1 failure";
                    StartCoroutine(WaitForDeath());
                    PlayerSpawn.player1 = false;
                }
            }
            else 
            {
                PlayerSpawn.player2Lives -= 1;
                if(PlayerSpawn.player2Lives == 0)
                {
                    Player2Text.player2Message = " ";
                    Player1Text.player1Message = "Player 1 Wins!";
                }
                else
                {
                    Player2Text.player2Message = "Player 2 failure";
                    StartCoroutine(WaitForDeath());
                    PlayerSpawn.player1 = true;
                }

            }

        }
        if (tagName == "Goal")
        {
            this.gameObject.transform.position = new Vector3(-100f, -100f, -100f);
        }


    }

    private IEnumerator WaitForDeath()
    {
        yield return new WaitForSeconds(4f);
        Player1Text.player1Message = " ";
        Player2Text.player2Message = " ";
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
