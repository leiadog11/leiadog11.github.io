using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpinningObstacleScript : MonoBehaviour
{
    public static float spinSpeed = 0f;
    public static bool LeftRight = false;
    public int randomizer;
    
  
    void Start()
    {
        spinSpeed = 1;
        randomizer = Random.Range(1, 3);
        if(randomizer == 1)
        {
            LeftRight = true;
        }
        if (randomizer == 2)
        {
            LeftRight = false;
        }

    }

    void Update()
    {
        if (LeftRight == true)
        {
            transform.Rotate(new Vector3(0, 0, spinSpeed));
        }
        else
        {
            transform.Rotate(new Vector3(0, 0, -spinSpeed));
        }
    }
}
