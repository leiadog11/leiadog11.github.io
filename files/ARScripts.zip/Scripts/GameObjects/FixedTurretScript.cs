using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FixedTurretScript : MonoBehaviour
{
    public float Range;
    public Transform Target;
    bool Detected = false;
    Vector3 Direction;
    public GameObject AlarmLight;
    public GameObject Gun;
    public GameObject Bullet;
    public float FireRate;
    private float NextTimeToShoot = 0;
    public Transform ShootPoint;
    public float Force;
    Vector3 targetPos;
    Vector3 startPos;

    void Start()
    {
        Vector3 targetPos = Target.position;
        Vector3 startPos = ShootPoint.position;
        Direction = targetPos - (Vector3)transform.position;
    }

    void Update()
    {
        Vector3 targetPos = Target.transform.position;
        Vector3 forward = transform.TransformDirection(Vector3.forward) * 10;
        Vector3 startPos = ShootPoint.transform.position;
        Debug.Log(Detected);
        Debug.DrawRay(startPos, targetPos, Color.green);
        Debug.DrawRay(transform.position, forward, Color.green);
        if (Physics.Raycast(startPos, targetPos, Range))
        {
            Detected = true;
        }
        else
        {
            Detected = false;
        }
        if (Detected == false)
        {
            AlarmLight.GetComponent<SpriteRenderer>().color = Color.green;
        }
        else if (Detected == true)
        {
            AlarmLight.GetComponent<SpriteRenderer>().color = Color.red;
            Gun.transform.up = Direction;
            if (Time.time > NextTimeToShoot)
            {
                NextTimeToShoot = Time.time + 1 / FireRate;
                shoot();
            }
        }

    }

    public void shoot()
    {
        GameObject BulletIns = Instantiate(Bullet, ShootPoint.position, Quaternion.identity);
        BulletIns.GetComponent<Rigidbody2D>().AddForce(Direction * Force);
    }
    private void OnDrawGizmosSelected()
    {
        Gizmos.DrawWireSphere(transform.position, Range);
    }
}
