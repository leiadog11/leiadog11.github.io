using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CoinScript : MonoBehaviour
{
    public int player1Score, player2Score;
    // Start is called before the first frame update
    void Start()
    {
        Player1Text.player1Message = " ";
        Player2Text.player2Message = " ";
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnCollisionExit2D(Collision2D coll)
    {
        string tagName = coll.collider.gameObject.tag;

        if (tagName == "Player")
        {
            this.gameObject.transform.position = new Vector3(-200f, -200f, -200f);
            if (PlayerSpawn.player1 == true)
            {
                Player1Score.player1Score++;
                Player1Text.player1Message = "Player 1 Success";
                StartCoroutine(WaitForSuccess());
                PlayerSpawn.player1 = false;
            }
            else if (PlayerSpawn.player1 == false)
            {
                Player2Score.player2Score++;
                Player2Text.player2Message = "Player 2 Success";
                StartCoroutine(WaitForSuccess());
                PlayerSpawn.player1 = true;
            }

        }
    }

    private IEnumerator WaitForSuccess()
    {
        yield return new WaitForSeconds(4f);
        Player1Text.player1Message = " ";
        Player2Text.player2Message = " ";
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
