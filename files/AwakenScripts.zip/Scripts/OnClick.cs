using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class OnClick : MonoBehaviour
{
    //Attach this script to the textbox object
    public static bool click = false; //public variable that tells if the textbox is being clicked or not
    public static int obClick = 0;

    void OnMouseDown() //Unity Method that detects if the mouse is clicked on the gameobjects collider
    {
        click = true;
    }

}
