using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Newstand : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {

    }

    void OnMouseDown() 
    {
        OnClick.obClick = 2;
    }
}
