using System.Collections;
using UnityEngine.SceneManagement;
using System.Collections.Generic;
using static System.Threading.Thread;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class JCTextbox : MonoBehaviour
{
    //Attach this script to a textmeshpro object
    //Rename this script to something else and don't forget to also change the class name above
    private static TextMeshProUGUI textMeshPro; //the text object this script is attached to, you will need a textmeshpro object in Unity
    public TMP_FontAsset MCFont; //font object, drag fonts onto this on the script
    public TMP_FontAsset FigureFont; 
    public TMP_FontAsset NarratorFont; 
    public TMP_FontAsset NewsManFont; 
    public Material MCFontMaterial; //you will also need the corresponding material
    public Material FigureFontMaterial;
    public Material NarratorFontMaterial;
    public Material NewsManFontMaterial;
    private string sentence; //sentence instance variable for the method
    public int input = 0; //increments the input to move on to the next line of text
    private int fontSize; //font size variable for the textbox
    public static int loop = 0; //loop variable to keep track of the script text
    public static int wokePoints = 0; //points for making right choices
    public static bool choice; //boolean for when a choice is made
    public static bool clickable;
    public bool done;
    private float textSpeed; //speed of the text instance variable
    private Animator anim; //animator object for the textbox
    private Animator backgroundAnim;
    private Animator peopleAnim;
    private Animator figureAnim;
    private Animator mcAnim;
    private Animator dvAnim;
    private enum Color { PINK, BLUE, GRAY, BLACK } //Color enum, you can add more values to any enum as you see fit for your part of the comic
    private enum TextColor { WHITE, BLACK } //TextColor enum
    private enum Font { MC, FIGURE, NARRATOR, NEWSMAN } //Font enum
    private Color boxColor; //Color instance variable for the textbox 
    private TextColor textColor; //TextColor instance variable for the text color
    private Font font; //Font instance variable for the text font, you will have to import all the fonts correctly to use them
    public GameObject TextBox; //Use this to attach a textbox game object to this script
    public GameObject Background;
    public GameObject Newstand;
    public GameObject People;
    public GameObject FigureOb;
    public GameObject MC;
    public GameObject DV;
    public GameObject skip;
    public AudioClip bedroomDoor;
    public AudioClip frontDoor;
    public AudioClip TVNoises;
    public AudioClip subway;
    public AudioClip smallCrowd;
    public AudioClip JCPodcast;
    AudioSource audioSource;

    // Start is called before the first frame update
    void Start()
    {
        audioSource = GetComponent<AudioSource>();
        anim = TextBox.GetComponent<Animator>();
        backgroundAnim = Background.GetComponent<Animator>();
        peopleAnim = People.GetComponent<Animator>();
        figureAnim = FigureOb.GetComponent<Animator>();
        mcAnim = MC.GetComponent<Animator>();
        dvAnim = DV.GetComponent<Animator>();
        choice = false;
        textMeshPro = GetComponent<TextMeshProUGUI>();
        textMeshPro.text = "";

        TextBox.SetActive(false);
        People.SetActive(false);
        FigureOb.SetActive(false);
        DV.SetActive(false);
        skip.SetActive(false);
        StartCoroutine(PausePlusInput(0f));
    }

    public void Script() //the main method for the entire script
    {
        if (loop == 0) //loop 0 script
        {
            switch (input)
            {
                case 1:
                    MC.SetActive(true);
                    mcAnim.Play("Laying B&W");
                    backgroundAnim.Play("Bed Top");
                    StartCoroutine(PausePlusInput(4f));
                    break;
                case 2:
                    MC.SetActive(false);
                    backgroundAnim.Play("Calendar");
                    StartCoroutine(PausePlusInput(3f));
                    break;
                case 3:
                    backgroundAnim.Play("Full Bedroom Zoom");
                    StartCoroutine(PausePlusInput(2.6f));
                    break;
                case 4:
                    TextBox.SetActive(true);
                    MC.SetActive(true);
                    mcAnim.Play("Bed1Appear B&W");
                    backgroundAnim.Play("Full Bedroom");
                    MainCharacter();
                    sentence = "Guess I should get going.";
                    StartCoroutine(WriteMessage(sentence, boxColor, textColor, textSpeed, font, fontSize));
                    break;
                case 5:
                    TextBox.SetActive(false);
                    mcAnim.Play("BedToDoor B&W");
                    StartCoroutine(PausePlusInput(2f));
                    break;
                case 6:
                    TextBox.SetActive(true);
                    MC.SetActive(false);
                    backgroundAnim.Play("BlackBackground");
                    Narrator();
                    audioSource.PlayOneShot(bedroomDoor, 0.7F);
                    sentence = "> She grabs some clothes and heads out of her room.";
                    StartCoroutine(WriteMessage(sentence, boxColor, textColor, textSpeed, font, fontSize));
                    break;
                case 7:
                    TextBox.SetActive(false);
                    StartCoroutine(PausePlusInput(1f));
                    break;
                case 8:
                    MC.SetActive(true);
                    audioSource.clip = TVNoises;
                    audioSource.Play();
                    mcAnim.Play("Sitting B&W");
                    backgroundAnim.Play("Kitchen");
                    StartCoroutine(PausePlusInput(2f));
                    break;
                case 9:
                    TextBox.SetActive(true);
                    sentence = "> She makes herself some breakfast for the day.";
                    StartCoroutine(WriteMessage(sentence, boxColor, textColor, textSpeed, font, fontSize));
                    break;
                case 10:
                    NewsMan();
                    sentence = "Welcome back to the Prophacy TV. We have everything that you need to know for the day.";
                    break;
                case 11:
                    MC.SetActive(false);
                    backgroundAnim.Play("News");
                    sentence = "Today there will be 8 car crashes in the local area. Watch out for rain starting at 5:46 PM lasting until 2:32 AM.";
                    break;
                case 12:
                    backgroundAnim.Play("Kitchen");
                    MC.SetActive(true);
                    MainCharacter();
                    sentence = "Time for school.";
                    break;
                case 13:
                    audioSource.Stop();
                    MC.SetActive(false);
                    backgroundAnim.Play("BlackBackground");
                    Narrator();
                    sentence = "> She walks out the door and heads towards the subway entrance.";
                    break;
                case 14:
                    audioSource.PlayOneShot(frontDoor, 0.7F);
                    TextBox.SetActive(false);
                    StartCoroutine(PausePlusInput(1.5f));
                    break;
                case 15:
                    audioSource.clip = smallCrowd;
                    audioSource.Play();
                    MC.SetActive(true);
                    TextBox.SetActive(true);
                    People.SetActive(true);
                    peopleAnim.Play("Mob");
                    mcAnim.Play("Standing B&W");
                    backgroundAnim.Play("Subway");
                    MainCharacter();
                    sentence = "The news said the train would be 2 minutes late today.";
                    StartCoroutine(WriteMessage(sentence, boxColor, textColor, textSpeed, font, fontSize));
                    break;
                case 16:
                    MC.SetActive(false);
                    peopleAnim.Play("Salesman");
                    backgroundAnim.Play("Subway Side");
                    sentence = "I should pick up the Prophacy Paper while I wait.";
                    break;
                case 17:
                    sentence = "Let's see what it is today.";
                    break;
                case 18:
                    Narrator();
                    sentence = "> She purchases the daily paper.";
                    break;
                case 19:
                    People.SetActive(false);
                    backgroundAnim.Play("Paper");
                    MainCharacter();
                    sentence = "I think I�ve already seen this.";
                    break;
                case 20:
                    MC.SetActive(true);
                    People.SetActive(true);
                    peopleAnim.Play("Mob");
                    backgroundAnim.Play("Subway");
                    sentence = "The train is here.";
                    break;
                case 21:
                    audioSource.Stop();
                    audioSource.PlayOneShot(subway, 0.7F);
                    People.SetActive(false);
                    MC.SetActive(false);
                    backgroundAnim.Play("BlackBackground");
                    Narrator();
                    sentence = "> She gets on the train and heads to school.";
                    break;
                case 22:
                    MC.SetActive(false);
                    People.SetActive(false);
                    TextBox.SetActive(false);
                    sentence = "";
                    StartCoroutine(PausePlusInput(0.5f));
                    break;
                case 23:
                    skip.SetActive(true);
                    DV.SetActive(true);
                    dvAnim.Play("FadeIn");
                    audioSource.PlayOneShot(JCPodcast, 0.7F);
                    StartCoroutine(PausePlusInput(41f));
                    break;
                case 24: //next scene
                    DV.SetActive(false);
                    input = 0;
                    int nextSceneIndex = SceneManager.GetActiveScene().buildIndex + 1;
                    SceneManager.LoadScene(nextSceneIndex);
                    break;
            }

        } //loop 0 script
        if (loop == 1) //loop 1 script
        {
            switch (input)
            {
                case 1:
                    MC.SetActive(true);
                    mcAnim.Play("Laying");
                    backgroundAnim.Play("Bed Top");
                    StartCoroutine(PausePlusInput(3f));
                    break;
                case 2:
                    MC.SetActive(false);
                    TextBox.SetActive(false);
                    backgroundAnim.Play("Calendar");
                    StartCoroutine(PausePlusInput(3f));
                    break;
                case 3:
                    backgroundAnim.Play("Full Bedroom Zoom");
                    StartCoroutine(PausePlusInput(3f));
                    break;
                case 4:
                    MC.SetActive(true);
                    mcAnim.Play("Laying");
                    TextBox.SetActive(true);
                    backgroundAnim.Play("Bed Top");
                    MainCharacter();
                    sentence = "What�s that ringing in my ears?";
                    StartCoroutine(WriteMessage(sentence, boxColor, textColor, textSpeed, font, fontSize));
                    break;
                case 5:
                    sentence = "Must've been a bad dream...";
                    break;
                case 6:
                    mcAnim.Play("Bed1Appear");
                    backgroundAnim.Play("Full Bedroom");
                    sentence = "Guess I should get moving.";
                    break;
                case 7:
                    mcAnim.Play("BedToDoor");
                    TextBox.SetActive(false);
                    StartCoroutine(PausePlusInput(2f));
                    break;
                case 8:
                    audioSource.PlayOneShot(bedroomDoor, 0.7F);
                    MC.SetActive(false);
                    TextBox.SetActive(true);
                    backgroundAnim.Play("BlackBackground");
                    Narrator();
                    sentence = "> She grabs some clothes and heads out of her room.";
                    StartCoroutine(WriteMessage(sentence, boxColor, textColor, textSpeed, font, fontSize));
                    break;
                case 9:
                    TextBox.SetActive(false);
                    StartCoroutine(PausePlusInput(1f));
                    break;
                case 10:
                    audioSource.clip = TVNoises;
                    audioSource.Play();
                    MC.SetActive(true);
                    mcAnim.Play("Sitting");
                    backgroundAnim.Play("Kitchen");
                    StartCoroutine(PausePlusInput(2f));
                    break;
                case 11:
                    TextBox.SetActive(true);
                    sentence = "> She makes herself some breakfast for the day.";
                    StartCoroutine(WriteMessage(sentence, boxColor, textColor, textSpeed, font, fontSize));
                    break;
                case 12:
                    NewsMan();
                    sentence = "Welcome back to the Prophacy TV. We have everything that you need to know for the day.";
                    break;
                case 13:
                    MainCharacter();
                    sentence = "Why is the TV always on the news?";
                    break;
                case 14:
                    sentence = "Isn't there anything better on?";
                    break;
                case 15:
                    MC.SetActive(false);
                    backgroundAnim.Play("News");
                    NewsMan();
                    sentence = "Josh Freedman will buy the winning lottery ticket today at 4:05 PM.";
                    break;
                case 16:
                    backgroundAnim.Play("Kitchen");
                    MC.SetActive(true);
                    MainCharacter();
                    sentence = "Time for school.";
                    break;
                case 17:
                    audioSource.Stop();
                    MC.SetActive(false);
                    backgroundAnim.Play("BlackBackground");
                    Narrator();
                    sentence = "> She walks out the door and heads towards the subway entrance.";
                    break;
                case 18:
                    audioSource.PlayOneShot(frontDoor, 0.7F);
                    TextBox.SetActive(false);
                    StartCoroutine(PausePlusInput(1.5f));
                    break;
                case 19:
                    audioSource.clip = smallCrowd;
                    audioSource.Play();
                    MC.SetActive(true);
                    TextBox.SetActive(true);
                    People.SetActive(true);
                    peopleAnim.Play("Mob");
                    mcAnim.Play("Standing");
                    backgroundAnim.Play("Subway");
                    MainCharacter();
                    sentence = "I wonder what's going to happen today.";
                    StartCoroutine(WriteMessage(sentence, boxColor, textColor, textSpeed, font, fontSize));
                    break;
                case 20:
                    MC.SetActive(false);
                    FigureOb.SetActive(true);
                    peopleAnim.Play("Salesman");
                    figureAnim.Play("Small");
                    backgroundAnim.Play("Subway Side");
                    sentence = "Wait...";
                    break;
                case 21:
                    sentence = "I feel like, that thing in the corner, I've seen it before...";
                    break;
                case 22:
                    sentence = "I must not have gotten enough sleep.";
                    break;
                case 23:
                    Narrator();
                    sentence = "> She purchases the daily paper.";
                    break;
                case 24:
                    People.SetActive(false);
                    FigureOb.SetActive(false);
                    backgroundAnim.Play("PaperWithBracelet");
                    MainCharacter();
                    sentence = "Seems familiar.";
                    break;
                case 25:
                    MC.SetActive(true);
                    People.SetActive(true);
                    peopleAnim.Play("Mob");
                    backgroundAnim.Play("Subway");
                    sentence = "The train is here.";
                    break;
                case 26:
                    audioSource.Stop();
                    audioSource.PlayOneShot(subway, 0.7F);
                    MC.SetActive(false);
                    People.SetActive(false);
                    backgroundAnim.Play("BlackBackground");
                    Narrator();
                    sentence = "> She gets on the train and heads to school.";
                    break;
                case 27:
                    MC.SetActive(false);
                    People.SetActive(false);
                    TextBox.SetActive(false);
                    sentence = "";
                    StartCoroutine(PausePlusInput(0.5f));
                    break;
                case 28: //next scene
                    input = 0;
                    int nextSceneIndex = SceneManager.GetActiveScene().buildIndex + 1;
                    SceneManager.LoadScene(nextSceneIndex);
                    break;
            }

        } //loop 1 script
        if (loop == 2) //loop 2 script
        {
            switch (input)
            {
                case 1:
                    if (wokePoints >= 1)
                    {
                        MC.SetActive(true);
                        mcAnim.Play("Laying");
                        TextBox.SetActive(true);
                        backgroundAnim.Play("Bed Top");
                        MainCharacter();
                        sentence = "I CHOOSE!!";
                        StartCoroutine(WriteMessage(sentence, boxColor, textColor, textSpeed, font, fontSize));
                    }
                    else
                    {
                        MC.SetActive(false);
                        TextBox.SetActive(false);
                        backgroundAnim.Play("Calendar");
                        StartCoroutine(PausePlusInput(5f));
                    }
                    break;
                case 2:
                    if (wokePoints >= 1)
                    {
                        sentence = "...";
                    }
                    else
                    {
                        backgroundAnim.Play("Full Bedroom Zoom");
                        StartCoroutine(PausePlusInput(3f));
                    }
                    break;
                case 3:
                    if (wokePoints >= 1)
                    {
                        sentence = "Those...people...";
                    }
                    else
                    {
                        StartCoroutine(PausePlusInput(0.0001f));
                    }
                    break;
                case 4:
                    if (wokePoints >= 1)
                    {
                        MC.SetActive(true);
                        TextBox.SetActive(true);
                        mcAnim.Play("Bed1Appear");
                        backgroundAnim.Play("Full Bedroom");
                        sentence = "I need to get moving.";
                    }
                    else
                    {
                        MC.SetActive(true);
                        TextBox.SetActive(true);
                        mcAnim.Play("Bed1Appear");
                        backgroundAnim.Play("Full Bedroom");
                        MainCharacter();
                        sentence = "I need to get moving.";
                        StartCoroutine(WriteMessage(sentence, boxColor, textColor, textSpeed, font, fontSize));
                    }
                    break;
                case 5:
                    TextBox.SetActive(false);
                    MC.SetActive(true);
                    mcAnim.Play("BedToDoor");
                    StartCoroutine(PausePlusInput(2f));
                    break;
                case 6:
                    audioSource.PlayOneShot(bedroomDoor, 0.7F);
                    TextBox.SetActive(true);
                    MC.SetActive(false);
                    Narrator();
                    backgroundAnim.Play("BlackBackground");
                    if (wokePoints >= 1)
                    {
                        sentence = "> She grabs some clothes in a panic and heads out of her room.";
                    }
                    else
                    {
                        sentence = "> She grabs some clothes and heads out of her room.";
                    }
                    StartCoroutine(WriteMessage(sentence, boxColor, textColor, textSpeed, font, fontSize));
                    break;
                case 7:
                    TextBox.SetActive(false);
                    StartCoroutine(PausePlusInput(1f));
                    break;
                case 8:
                    audioSource.clip = TVNoises;
                    audioSource.Play();
                    MC.SetActive(true);
                    mcAnim.Play("Sitting");
                    backgroundAnim.Play("Kitchen");
                    TextBox.SetActive(true);
                    sentence = "> She makes herself some breakfast for the day.";
                    StartCoroutine(WriteMessage(sentence, boxColor, textColor, textSpeed, font, fontSize));
                    break;
                case 9:
                    NewsMan();
                    sentence = "But what is the flow of time, can I swim the other direction? Can I wade in place?";
                    break;
                case 10:
                    MainCharacter();
                    sentence = "More of the same.";
                    break;
                case 11:
                    if (wokePoints >= 1)
                    {
                        sentence = "Maybe school will clear my head...";
                    }
                    else
                    {
                        sentence = "Time for school.";
                    }
                    break;
                case 12:
                    audioSource.Stop();
                    MC.SetActive(false);
                    Narrator();
                    backgroundAnim.Play("BlackBackground");
                    if (wokePoints >= 1)
                    {
                        sentence = "> She walks out the door and heads quickly towards the subway entrance.";
                    }
                    else
                    {
                        sentence = "> She heads towards the subway entrance.";
                    }
                    break;
                case 13:
                    audioSource.PlayOneShot(frontDoor, 0.7F);
                    TextBox.SetActive(false);
                    StartCoroutine(PausePlusInput(1.5f));
                    break;
                case 14:
                    audioSource.clip = smallCrowd;
                    audioSource.Play();
                    MC.SetActive(true);
                    TextBox.SetActive(true);
                    People.SetActive(true);
                    peopleAnim.Play("Mob");
                    mcAnim.Play("Standing");
                    backgroundAnim.Play("Subway");
                    MainCharacter();
                    sentence = "The paper, maybe I can see what happens to me tonight.";
                    StartCoroutine(WriteMessage(sentence, boxColor, textColor, textSpeed, font, fontSize));
                    break;
                case 15:
                    MC.SetActive(false);
                    FigureOb.SetActive(true);
                    figureAnim.Play("Small");
                    peopleAnim.Play("Salesman");
                    backgroundAnim.Play("Subway Side");
                    sentence = "!!!";
                    break;
                case 16:
                    sentence = "That thing...I've definitely seen it before...";
                    break;
                case 17:
                    sentence = "";
                    clickable = true;
                    TextBox.SetActive(false);
                    Newstand.SetActive(true);
                    figureAnim.Play("Glow");
                    StartCoroutine(WaitForChoice());
                    break;
                case 18:
                    TextBox.SetActive(true);
                    Newstand.SetActive(false);
                    figureAnim.Play("Small");
                    if(choice)
                    {
                        sentence = "What am I doing..?";
                        StartCoroutine(WriteMessage(sentence, boxColor, textColor, textSpeed, font, fontSize));
                    }
                    else
                    {
                        sentence = "I must have seen it in one of the papers, let me check todays.";
                        StartCoroutine(WriteMessage(sentence, boxColor, textColor, textSpeed, font, fontSize));
                    }
                    break;
                case 19:
                    if (choice)
                    {
                        audioSource.Stop();
                        People.SetActive(false);
                        figureAnim.Play("Big");
                        backgroundAnim.Play("FigureBackground");
                        sentence = "Hi, I feel like I know you.";
                    }
                    else
                    {
                        Narrator();
                        sentence = "> She purchases the daily paper.";
                    }
                    break;
                case 20:
                    if (choice)
                    {
                        Figure();
                        sentence = "Good choice";
                    }
                    else
                    {
                        TextBox.SetActive(false);
                        People.SetActive(false);
                        FigureOb.SetActive(false);
                        backgroundAnim.Play("PaperWithBracelet");
                        StartCoroutine(PausePlusInput(2f));
                    }
                    break;
                case 21:
                    if (choice)
                    {
                        MainCharacter();
                        sentence = "Excuse me?";
                    }
                    else
                    {
                        TextBox.SetActive(true);
                        MainCharacter();
                        sentence = "That thing isn't on here, strange.";
                        StartCoroutine(WriteMessage(sentence, boxColor, textColor, textSpeed, font, fontSize));
                    }
                    break;
                case 22:
                    if (choice)
                    {
                        Figure();
                        sentence = "First step to awakening";
                    }
                    else
                    {
                        MC.SetActive(true);
                        backgroundAnim.Play("Subway");
                        sentence = "The train is here.";
                    }
                    break;
                case 23:
                    if (choice)
                    {
                        MainCharacter();
                        sentence = "I made a mistake...maybe I don't know you-";
                        figureAnim.Play("Fade");
                    }
                    else
                    {
                        audioSource.Stop();
                        audioSource.PlayOneShot(subway, 0.7F);
                        MC.SetActive(false);
                        backgroundAnim.Play("BlackBackground");
                        Narrator();
                        sentence = "She gets on the train and heads to school.";
                    }
                    break;
                case 24:
                    TextBox.SetActive(false);
                    StartCoroutine(PausePlusInput(2f));
                    break;
                case 25:
                    if (choice)
                    {
                        audioSource.PlayOneShot(subway, 0.7F);
                        FigureOb.SetActive(false);
                        TextBox.SetActive(true);
                        sentence = "What have I done...";
                        StartCoroutine(WriteMessage(sentence, boxColor, textColor, textSpeed, font, fontSize));
                    }
                    else
                    {
                        StartCoroutine(PausePlusInput(0.0001f));
                    }
                    break;
                case 26:
                    if (choice)
                    {
                        MC.SetActive(false);
                        backgroundAnim.Play("BlackBackground");
                        Narrator();
                        sentence = "She gets on the train in a rush and heads to school.";
                    }
                    else
                    {
                        StartCoroutine(PausePlusInput(0.0001f));
                    }
                    break;
                case 27:
                    if (choice)
                    {
                        TextBox.SetActive(false);
                        choice = false;
                        StartCoroutine(PausePlusInput(2f));
                    }
                    else
                    {
                        StartCoroutine(PausePlusInput(0.0001f));
                    }
                    break;
                case 28:
                    MC.SetActive(false);
                    People.SetActive(false);
                    TextBox.SetActive(false);
                    sentence = "";
                    StartCoroutine(PausePlusInput(0.5f));
                    break;
                case 29: //next scene
                    input = 0;
                    int nextSceneIndex = SceneManager.GetActiveScene().buildIndex + 1;
                    SceneManager.LoadScene(nextSceneIndex);
                    break;
            }

        } //loop 2 script
        if (loop == 3)
        {
            switch (input)
            {
                case 1:
                    if (wokePoints >= 3)
                    {
                        TextBox.SetActive(true);
                        MC.SetActive(true);
                        mcAnim.Play("Laying");
                        backgroundAnim.Play("Bed Top");
                        MainCharacter();
                        sentence = "Wait...where am I?";
                        StartCoroutine(WriteMessage(sentence, boxColor, textColor, textSpeed, font, fontSize));
                    }
                    else
                    {
                        TextBox.SetActive(false);
                        backgroundAnim.Play("Calendar");
                        StartCoroutine(PausePlusInput(2f));
                    }
                    break;
                case 2:
                    if (wokePoints >= 3)
                    {
                        sentence = "I thought I didn't take the train...why am I back here...?";
                    }
                    else
                    {
                        backgroundAnim.Play("Bed Top");
                        MC.SetActive(true);
                        mcAnim.Play("Laying");
                        TextBox.SetActive(true);
                        MainCharacter();
                        sentence = "This is starting to seem familiar...";
                        StartCoroutine(WriteMessage(sentence, boxColor, textColor, textSpeed, font, fontSize));
                    }
                    break;
                case 3:
                    if (wokePoints >= 3)
                    {
                        backgroundAnim.Play("Full Bedroom");
                        mcAnim.Play("Bed1Appear");
                        sentence = "I need to do something about this.";
                    }
                    else
                    {
                        sentence = "It must be in my head.";
                    }
                    break;
                case 4:
                    if (wokePoints >= 3)
                    {
                        TextBox.SetActive(false);
                        mcAnim.Play("BedToDoor");
                        StartCoroutine(PausePlusInput(2f));
                    }
                    else
                    {
                        MC.SetActive(true);
                        mcAnim.Play("Bed1Appear");
                        backgroundAnim.Play("Full Bedroom");
                        sentence = "Time to get going.";
                    }
                    break;
                case 5:
                    if (wokePoints >= 3)
                    {
                        audioSource.PlayOneShot(bedroomDoor, 0.7F);
                        TextBox.SetActive(true);
                        MC.SetActive(false);
                        backgroundAnim.Play("BlackBackground");
                        Narrator();
                        sentence = "> This story seems out of my grasp.";
                        StartCoroutine(WriteMessage(sentence, boxColor, textColor, textSpeed, font, fontSize));
                    }
                    else
                    {
                        TextBox.SetActive(false);
                        mcAnim.Play("BedToDoor");
                        StartCoroutine(PausePlusInput(2f));
                    }
                    break;
                case 6:
                    if (wokePoints >= 3)
                    {
                        TextBox.SetActive(false);
                        StartCoroutine(PausePlusInput(1f));
                    }
                    else
                    {
                        audioSource.PlayOneShot(bedroomDoor, 0.7F);
                        TextBox.SetActive(true);
                        MC.SetActive(false);
                        backgroundAnim.Play("BlackBackground");
                        Narrator();
                        sentence = "> She grabs some clothes and heads out of her room.";
                        StartCoroutine(WriteMessage(sentence, boxColor, textColor, textSpeed, font, fontSize));
                    }
                    break;
                case 7:
                    if (wokePoints >= 3)
                    {
                        audioSource.clip = TVNoises;
                        audioSource.Play();
                        backgroundAnim.Play("Kitchen");
                        MC.SetActive(true);
                        mcAnim.Play("Standing2");
                        StartCoroutine(PausePlusInput(0.5f));
                    }
                    else
                    {
                        TextBox.SetActive(false);
                        StartCoroutine(PausePlusInput(1f));
                    }
                    break;
                case 8:
                    if (wokePoints >= 3)
                    {
                        TextBox.SetActive(true);
                        MainCharacter();
                        sentence = "No time for breakfast.";
                        StartCoroutine(WriteMessage(sentence, boxColor, textColor, textSpeed, font, fontSize));
                    }
                    else
                    {
                        audioSource.clip = TVNoises;
                        backgroundAnim.Play("Kitchen");
                        MC.SetActive(true);
                        mcAnim.Play("Sitting");
                        StartCoroutine(PausePlusInput(0.5f));
                    }
                    break;
                case 9:
                    if (wokePoints >= 3)
                    {
                        NewsMan();
                        sentence = "Wake up. Wake up. Wake up.";
                    }
                    else
                    {
                        TextBox.SetActive(true);
                        MainCharacter();
                        sentence = "I don't feel hungry today.";
                        StartCoroutine(WriteMessage(sentence, boxColor, textColor, textSpeed, font, fontSize));
                    }
                    break;
                case 10:
                    if (wokePoints >= 3)
                    {
                        MainCharacter();
                        sentence = "Or the news.";
                    }
                    else
                    {
                        NewsMan();
                        sentence = "Today we have reports of people struggling to wake up, continuing to sleep.";
                    }
                    break;
                case 11:
                    if (wokePoints >= 3)
                    {
                        audioSource.Stop();
                        MC.SetActive(false);
                        backgroundAnim.Play("BlackBackground");
                        sentence = "To the subway.";
                    }
                    else
                    {
                        MC.SetActive(false);
                        backgroundAnim.Play("News");
                        sentence = "If you need to rethink, reevaluate, and restart, do so as soon as possible.";
                    }
                    break;
                case 12:
                    if (wokePoints >= 3)
                    {
                        audioSource.PlayOneShot(frontDoor, 0.7F);
                        TextBox.SetActive(false);
                        StartCoroutine(PausePlusInput(1.5f));
                    }
                    else
                    {
                        MC.SetActive(true);
                        backgroundAnim.Play("Kitchen");
                        MainCharacter();
                        sentence = "Time for school.";
                    }
                    break;
                case 13:
                    if (wokePoints >= 3)
                    {
                        audioSource.clip = smallCrowd;
                        audioSource.Play();
                        People.SetActive(true);
                        peopleAnim.Play("Mob");
                        backgroundAnim.Play("Subway");
                        MC.SetActive(true);
                        mcAnim.Play("Standing");
                        StartCoroutine(PausePlusInput(1.5f));
                    }
                    else
                    {
                        MC.SetActive(false);
                        backgroundAnim.Play("BlackBackground");
                        Narrator();
                        sentence = "> She heads to the subway.";
                    }
                    break;
                case 14:
                    if (wokePoints >= 3)
                    {
                        MC.SetActive(false);
                        TextBox.SetActive(true);
                        peopleAnim.Play("Salesman");
                        backgroundAnim.Play("Subway Side");
                        sentence = "It's not there, why is it not there.";
                        StartCoroutine(WriteMessage(sentence, boxColor, textColor, textSpeed, font, fontSize));
                    }
                    else
                    {
                        audioSource.PlayOneShot(frontDoor, 0.7F);
                        TextBox.SetActive(false);
                        StartCoroutine(PausePlusInput(1.5f));
                    }
                    break;
                case 15:
                    if (wokePoints >= 3)
                    {
                        peopleAnim.Play("Mob");
                        MC.SetActive(true);
                        backgroundAnim.Play("Subway");
                        sentence = "I'm going to school.";
                    }
                    else
                    {
                        audioSource.clip = smallCrowd;
                        audioSource.Play(); 
                        MC.SetActive(true);
                        People.SetActive(true);
                        peopleAnim.Play("Mob");
                        mcAnim.Play("Standing");
                        backgroundAnim.Play("Subway");
                        StartCoroutine(PausePlusInput(0.5f));
                    }
                    break;
                case 16:
                    if (wokePoints >= 3)
                    {
                        People.SetActive(false);
                        TextBox.SetActive(false);
                        MC.SetActive(false);
                        audioSource.Stop();
                        audioSource.PlayOneShot(subway, 0.7F);
                        backgroundAnim.Play("BlackBackground");
                        StartCoroutine(PausePlusInput(1f));
                    }
                    else
                    {
                        TextBox.SetActive(true);
                        MainCharacter();
                        sentence = "The paper is getting more predictable. I'll just wait patiently.";
                        StartCoroutine(WriteMessage(sentence, boxColor, textColor, textSpeed, font, fontSize));
                    }
                    break;
                case 17:
                    if (wokePoints >= 3)
                    {
                        StartCoroutine(PausePlusInput(0.00001f));
                    }
                    else
                    {
                        audioSource.Stop();
                        audioSource.PlayOneShot(subway, 0.7F);
                        People.SetActive(false);
                        MC.SetActive(false);
                        backgroundAnim.Play("BlackBackground");
                        Narrator();
                        sentence = "> The subway arrives and she heads to school.";
                    }
                    break;
                case 18:
                    MC.SetActive(false);
                    People.SetActive(false);
                    TextBox.SetActive(false);
                    sentence = "";
                    StartCoroutine(PausePlusInput(0.5f));
                    break;
                case 19: //next scene
                    input = 0;
                    int nextSceneIndex = SceneManager.GetActiveScene().buildIndex + 1;
                    SceneManager.LoadScene(nextSceneIndex);
                    break;
            }
        } //loop 3 script
    }

    IEnumerator WriteMessage(string sentence, Color textboxColor, TextColor textColor, float textSpeed, Font font , int fontSize)//, audio clip) //takes in the six parameters, changes the textbox color, text color, text speed, font, and then types out the sentence letter by letter
    {
        OnClick.click = false;
        switch (textboxColor) //sets the textbox color
        {
            case Color.PINK: //uses the Color enum, call different colors with Color.(color) as used in this example
                anim.Play("PINK"); //the textbox color is actually different animation frames of the textbox object
                break;
            case Color.BLUE:
                anim.Play("BLUE");
                break;
            case Color.GRAY:
                anim.Play("GRAY");
                break;
            case Color.BLACK:
                anim.Play("BLACK");
                break;
        }
        switch (textColor) //sets the text color
        {
            case TextColor.WHITE:
                textMeshPro.color = new Color32(255,255,255, 255); //uses Color32 to make a new color (r,g,b,a)
                break;
            case TextColor.BLACK:
                textMeshPro.color = new Color32(0, 0, 0, 255);
                break;
        }
        switch (font) //sets the fonts
        {
            case Font.MC:
                textMeshPro.font = MCFont; //sets the font to the font you want
                textMeshPro.fontSharedMaterial = MCFontMaterial; //sets the font with the according material
                break;
            case Font.FIGURE:
                textMeshPro.font = FigureFont;
                textMeshPro.fontSharedMaterial = FigureFontMaterial;
                break;
            case Font.NARRATOR:
                textMeshPro.font = NarratorFont;
                textMeshPro.fontSharedMaterial = NarratorFontMaterial;
                break;
            case Font.NEWSMAN:
                textMeshPro.font = NewsManFont;
                textMeshPro.fontSharedMaterial = NewsManFontMaterial;
                break;
        }
        textMeshPro.text = ""; //sets the text at a clean slate
        textMeshPro.fontSize = fontSize; //sets the font size
        for (int i = 0; i < sentence.Length; i++) //this for loop types each letter in the sentence one by one as fast as the textSpeed is
        {
            done = false;
            textMeshPro.text = textMeshPro.text + sentence[i];
            if (OnClick.click)
            {
                OnClick.click = false;
                textMeshPro.text = sentence;
                break;
            }
            yield return new WaitForSeconds(textSpeed); //waits between letter placements using textSpeed
        }
        done = true;
        StartCoroutine(WaitForClick()); //calls the WaitForClick method found below

    }

    IEnumerator WaitForClick() //waits for the user to click on the textbox object
    {
        while (!OnClick.click && (done)) //waits until textbox is clicked 
        {
            yield return new WaitForSeconds(0.01f);
        }
        if (done)
        {
            OnClick.click = false; //resets the click value to false so it doesn't stay true forever
            done = false;
            input++;
            Script(); //calls the script method
            StartCoroutine(WriteMessage(sentence, boxColor, textColor, textSpeed, font, fontSize)); //recalls the method and gets put into a cycle of this calling the first method and that method calling this method
        }
    }
    IEnumerator WaitForChoice() //waits for the user to click on an object
    {
        while (OnClick.obClick == 0) //waits until object is clicked
        {
            yield return new WaitForSeconds(0.01f);
        }
        if(OnClick.obClick == 1)
        {
            clickable = false;
            choice = true;
            OnClick.obClick = 0;
            wokePoints++;
            input++;
            Script();
        }
        else if (OnClick.obClick == 2)
        {
            choice = false;
            OnClick.obClick = 0;
            input++;
            Script();
        }
    }

    IEnumerator PausePlusInput(float time) //Pauses for the amount of input, then increments the input and calls the script
    {
        sentence = " ";
        yield return new WaitForSeconds(time);
        input++;
        Script();
    }

    void MainCharacter() //sets the main characters traits for the text, try making your own!
    {
        boxColor = Color.PINK;
        textColor = TextColor.WHITE;
        textSpeed = 0.035f;
        font = Font.MC;
        fontSize = 38;
    }

    void Figure()
    {
        boxColor = Color.BLACK;
        textColor = TextColor.WHITE;
        textSpeed = 0.1f;
        font = Font.FIGURE;
        fontSize = 32;
    }

    void Narrator()
    {
        boxColor = Color.GRAY;
        textColor = TextColor.WHITE;
        textSpeed = 0.05f;
        font = Font.NARRATOR;
        fontSize = 30;
    }

    void NewsMan()
    {
        boxColor = Color.BLUE;
        textColor = TextColor.BLACK;
        textSpeed = 0.025f;
        font = Font.NEWSMAN;
        fontSize = 28;
    }

}
