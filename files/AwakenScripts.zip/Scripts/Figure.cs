using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Figure : MonoBehaviour
{
    private static Animator anim;
    // Start is called before the first frame update
    void Start()
    {
        anim = gameObject.GetComponent<Animator>();
    }

    void OnMouseDown()
    {
        if(JCTextbox.clickable == true)
        {
            OnClick.obClick = 1;
        }
    }
}
