using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreditsButton : MonoBehaviour
{
    public GameObject credits;
    public GameObject backButton;

    public void OnClick()
    {
        credits.SetActive(true);
        backButton.SetActive(true);
    }
  
}
