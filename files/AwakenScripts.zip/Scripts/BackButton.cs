using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BackButton : MonoBehaviour
{
    public GameObject credits;

    public void OnClick()
    {
        gameObject.SetActive(false);
        credits.SetActive(false);
    }
}
